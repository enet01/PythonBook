# -*- coding: utf-8 -*-
#!/usr/bin/env python

Net_driver = "eth0"
OMServer_address = "omserver.domain.com"
Connect_TimeOut = 3