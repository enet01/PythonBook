#《Python自动化运维：技术与最佳实践》附带示例及案例源码

##第十六章 OManager系统目录说明
+ data - 系统配置与数据目录
+ dist - 系统编译目录
+ img - 系统图片资源目录
+ Module - 系统自定义模块目录
+ numbers - 用户密钥目录
+ tmp - 系统临时目录
+ install.bat - 系统编译批处理文件
+ MD5sum.exe - MD5校验工具
+ OManager.spec - 系统pyinstall编译spec文件

##问题反馈

在使用中有任何问题，欢迎反馈给我，可以用以下联系方式跟我交流

* 问答平台 [qa.liuts.com](http://qa.liuts.com)
* 邮件(liutiansi@gmail.com)
* weibo: [@yorkoliu](http://weibo.com/u/1775431677)
* blog: [blog.liuts.com](http://blog.liuts.com)
* 微信号：yorkoliu