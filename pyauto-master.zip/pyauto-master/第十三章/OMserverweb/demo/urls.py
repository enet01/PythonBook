from django.conf.urls.defaults import *

urlpatterns = patterns('demo.views',
    (r'^$','index'),
)
