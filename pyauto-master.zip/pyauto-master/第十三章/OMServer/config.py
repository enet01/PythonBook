# -*- coding: utf-8 -*-
#!/usr/bin/env python

AUTO_PLATFORM = "func"
SECRET_KEY = "ctmj#&amp;8hrgow_^sj$ejt@9fzsmh_o)-=(byt5jmg=e3#foya6u"
