#《Python自动化运维：技术与最佳实践》附带示例及案例源码

##第一章 目录说明
+ dnspython - dnspython模块示例
+ IPy - IPy模块示例

##问题反馈

在使用中有任何问题，欢迎反馈给我，可以用以下联系方式跟我交流

* 问答平台 [qa.liuts.com](http://qa.liuts.com)
* 邮件(liutiansi@gmail.com)
* weibo: [@yorkoliu](http://weibo.com/u/1775431677)
* blog: [blog.liuts.com](http://blog.liuts.com)
* 微信号：yorkoliu