#!/bin/sh
ls /root
