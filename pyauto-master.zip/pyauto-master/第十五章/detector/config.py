# -*- coding: utf-8 -*-
#db info
DBNAME='WebMonitor'                      # Or path to database file if using sqlite3.
DBUSER='webmonitor_user'                      # Not used with sqlite3.
DBPASSWORD='SKJDH3745tgDTS'                  # Not used with sqlite3.
DBHOST='192.168.1.10'                      # Set to empty string for localhost. Not used with sqlite3.


#探测运营商网络
IDC="ct"

#连接的等待时间
CONNECTTIMEOUT = 5

#请求超时时间
TIMEOUT = 10

#告警邮件地址
MAILTO="user1@domain.com,user2@domain.com"

#告警手机号
MOBILETO="136****34634"