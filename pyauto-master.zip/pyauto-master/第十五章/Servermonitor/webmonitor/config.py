# -*- coding: utf-8 -*-
#db info
DBNAME='WebMonitor'                      # Or path to database file if using sqlite3.
DBUSER='webmonitor_user'                      # Not used with sqlite3.
DBPASSWORD='SKJDH3745tgDTS'                  # Not used with sqlite3.
DBHOST='192.168.1.10'                      # Set to empty string for localhost. Not used with sqlite3.

#system path
ProjectPATH="/data/www/Servermonitor"
RRDPATH=ProjectPATH+"/rrd"