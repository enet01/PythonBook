#!/usr/bin/perl

print "Content-type: text/html\n\n";
print "<html><head><title>Perl Cgi test page</title></head><body>";
print "<b>Perl Hello, world!</b>\n";
print "</body></html>"